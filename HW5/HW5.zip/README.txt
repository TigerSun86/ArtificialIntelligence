Question 2:

Class DecisionTreeLearning.java is the implement of decision tree algorithm asked by question 2, it contains 4 public functions as task asked:
1.
public static final DecisionTree learnDecisionTree (
            final ExampleList examples, final ArrayList<Attribute> attributes,
            final Object defaultClass)
2.            
public static final void printDecisionTree (final DecisionTree tree) 
3.
public static final double evalDecisionTree (final DecisionTree tree,
            final ExampleList testList) 
4.
public static final void testDecisionTree (final String attrFName,
            final String trainFName, final String testFName) 
            
By the way, the file name should be URL String such as:

"http://cs.fit.edu/~pkc/classes/ai/ml/ttt-attr.txt"


Question 3:
Class TestIDS.java and TestTTT.java are for the question 3 a) and b)

They have main function, just run it.

Question 4:
Class TTTDataGenerator.java can generate data randomly for both 9 attributes and 9+1 attributes.

It has main function, just run it.

The generated data files will be in the current folder.(I think)

The altered attribute files and also one set of generated data files can be found in the website:

http://my.fit.edu/~sunx2013/ArtificialIntelligence/HW5/DecisionTreeLearning/src/resource/ttt-move-attr.txt
