src code file: TestJug.java, TestMC.java (default package)
sample commad line:
java TestJug 0 0 astar
java TestJug 0 5 usc

java TestMC 3 3 left astar
java TestMC 1 1 right ucs
