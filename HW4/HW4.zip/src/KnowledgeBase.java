import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KnowledgeBase {
    private ArrayList<Clause> kb;

    public KnowledgeBase() {
        kb = new ArrayList<Clause>();
    }

    public final void tellKB (final String percepts) {
        addPercepts(kb, percepts);
    }

    public final boolean askKB (final String query) {
        final ArrayList<Clause> clauseSet = new ArrayList<Clause>();
        clauseSet.addAll(kb);
        final String negQuery = getNegQuery(query);
        addPercepts(clauseSet, negQuery);
        final ArrayList<Clause> newClauses = new ArrayList<Clause>();

        while (true) {
            newClauses.clear();
            for (int i = 0; i < clauseSet.size(); i++) {
                for (int j = i + 1; j < clauseSet.size(); j++) {
                    // Deal with each pair of clauses
                    final Clause resolvents =
                            Clause.resolve(clauseSet.get(i), clauseSet.get(j));
                    if (resolvents != null) {
                        // There is a new resolved clause
                        if (resolvents.isEmpty()) {
                            // Proved the query
                            return true;
                        }
                        if (!newClauses.contains(resolvents)) {
                            newClauses.add(resolvents);
                        }
                    }
                }
            }
            if (Clause.isSubSet(newClauses, clauseSet)) {
                // Have no enough knowledge to prove query
                return false;
            }
            // Add new clauses, and next loop scan all clauses
            Clause.add(clauseSet, newClauses);
        }
    }

    private void addPercepts (final ArrayList<Clause> clauseSet,
            final String percepts) {
        // Convert percepts into CNF
        final ArrayList<Clause> newClauses = new ArrayList<Clause>();
        // Add percepts into KB
        if (percepts.charAt(0) != '(') {
            // Only one clause in percepts
            newClauses.add(new Clause(percepts));
        } else {
            // Multi clause in percepts
            final Pattern p = Pattern.compile("\\((.*?)\\)");
            final Matcher m = p.matcher(percepts);
            while (m.find()) {
                // Add percepts into kb
                newClauses.add(new Clause(m.group(1)));
            }
        }
        // Add new percepts into clause set
        Clause.add(clauseSet, newClauses);
    }

    private String getNegQuery (final String query) {
        if (query.charAt(0) == '!') {
            return query.replace("!", "");
        } else {
            return "!" + query;
        }
    }
}
